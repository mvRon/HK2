number = int(input("Nhap vao 1 so nguyen duong:"))
if number<0:
    raise Exception("Khong dung yeu cau!")
else:
    print("Dung yeu cau!")
    